"""
model.py
--------
Arquitectura base del clasificador: un MLP (Multi-Layer Perceptron) de
pocas capas construido con nn.Sequential, tal como pide la consigna
("un clasificador lineal, o una red de pocas capas nn.Sequential").

Se devuelven logits crudos (sin softmax) porque nn.CrossEntropyLoss
aplica internamente log-softmax + NLLLoss.
"""

import torch.nn as nn


class MLPClassifier(nn.Module):
    """
    Clasificador simple: capa lineal -> ReLU -> capa lineal de salida.
    """

    def __init__(self, input_dim: int, hidden_dim: int, num_classes: int):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, x):
        return self.network(x)
