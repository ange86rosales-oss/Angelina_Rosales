"""
train.py
--------
Pipeline de entrenamiento y validación de un clasificador base en PyTorch.

Ciclo de vida implementado:
    1. Configuración del entorno (dispositivo + semilla).
    2. Carga de datos (train/validation).
    3. Definición de la arquitectura (MLP simple).
    4. Training loop: forward -> loss -> zero_grad -> backward -> step.
    5. Validation loop: evaluación en datos no vistos (sin backward).
    6. Tracking de métricas (loss y accuracy) por época.

Uso:
    python src/train.py
    python src/train.py --epochs 100 --lr 0.01 --hidden-dim 16
"""

import argparse
import csv
import json
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim

from dataset import load_iris_dataloaders
from model import MLPClassifier
from utils import get_device, set_seed

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "data"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pipeline base de entrenamiento en PyTorch")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--hidden-dim", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def run_epoch(model, loader, criterion, optimizer, device, train: bool):
    """
    Ejecuta una época completa sobre `loader`.
    Si `train=True`: hace zero_grad -> backward -> step (aprende).
    Si `train=False`: solo forward, sin tocar gradientes (validación).
    """
    model.train(mode=train)

    total_loss = 0.0
    correct = 0
    total = 0

    context = torch.enable_grad() if train else torch.no_grad()
    with context:
        for X_batch, y_batch in loader:
            # Consistencia de dispositivos: todos los tensores al mismo device.
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            if train:
                optimizer.zero_grad()

            # Forward pass
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)

            if train:
                # Backward pass (autograd) + actualización de pesos (Adam)
                loss.backward()
                optimizer.step()

            total_loss += loss.item() * X_batch.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds == y_batch).sum().item()
            total += X_batch.size(0)

    avg_loss = total_loss / total
    accuracy = correct / total
    return avg_loss, accuracy


def main():
    args = parse_args()

    # 1. Configuración del entorno: semilla + dispositivo
    set_seed(args.seed)
    device = get_device()
    print(f"Usando dispositivo: {device}")
    print(f"Versión de PyTorch: {torch.__version__}")

    # 2. Datos
    data = load_iris_dataloaders(batch_size=args.batch_size, seed=args.seed)

    # 3. Modelo, pérdida y optimizador
    model = MLPClassifier(
        input_dim=data.input_dim,
        hidden_dim=args.hidden_dim,
        num_classes=data.num_classes,
    ).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    # 4-5-6. Ciclo de entrenamiento + validación con tracking de métricas
    history = []
    print("\nIniciando entrenamiento...\n")
    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = run_epoch(model, data.train_loader, criterion, optimizer, device, train=True)
        val_loss, val_acc = run_epoch(model, data.val_loader, criterion, optimizer, device, train=False)

        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "train_acc": train_acc,
                "val_loss": val_loss,
                "val_acc": val_acc,
            }
        )

        if epoch % 10 == 0 or epoch == 1:
            print(
                f"Epoch [{epoch:3d}/{args.epochs}] "
                f"train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
                f"val_loss={val_loss:.4f} val_acc={val_acc:.4f}"
            )

    # Persistimos historial y resumen para trazabilidad del experimento
    OUTPUT_DIR.mkdir(exist_ok=True)

    with open(OUTPUT_DIR / "training_history.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=history[0].keys())
        writer.writeheader()
        writer.writerows(history)

    summary = {
        "pytorch_version": torch.__version__,
        "device": str(device),
        "epochs": args.epochs,
        "learning_rate": args.lr,
        "batch_size": args.batch_size,
        "hidden_dim": args.hidden_dim,
        "seed": args.seed,
        "final_train_loss": history[-1]["train_loss"],
        "final_train_acc": history[-1]["train_acc"],
        "final_val_loss": history[-1]["val_loss"],
        "final_val_acc": history[-1]["val_acc"],
    }
    with open(OUTPUT_DIR / "run_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("\nEntrenamiento finalizado.")
    print(f"Accuracy final en validación: {summary['final_val_acc']:.4f}")
    print(f"Historial guardado en: {OUTPUT_DIR / 'training_history.csv'}")


if __name__ == "__main__":
    main()
