"""
utils.py
--------
Utilidades de configuración del entorno de Deep Learning:
- Fijar semillas de aleatoriedad para reproducibilidad.
- Detectar automáticamente el mejor dispositivo disponible (CUDA > MPS > CPU).
"""

import random

import numpy as np
import torch


def set_seed(seed: int = 42) -> None:
    """Fija la semilla en Python, NumPy y PyTorch (CPU y CUDA) para
    que el experimento sea reproducible."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    """Detecta automáticamente el dispositivo disponible: CUDA (GPU NVIDIA),
    MPS (GPU Apple Silicon) o, en su defecto, CPU."""
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")
