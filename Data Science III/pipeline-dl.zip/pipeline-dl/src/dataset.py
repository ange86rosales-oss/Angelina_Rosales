"""
dataset.py
----------
Carga y preparación del dataset de referencia (Iris) para el pipeline
de entrenamiento y validación.

Se usa Iris (clásico, multi-clase, 4 features numéricas) en lugar de
MNIST para evitar dependencias de descarga externa: se carga localmente
desde scikit-learn, lo cual mantiene el checkpoint reproducible sin
conexión a internet.
"""

from dataclasses import dataclass

import numpy as np
import torch
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset


@dataclass
class DataBundle:
    train_loader: DataLoader
    val_loader: DataLoader
    input_dim: int
    num_classes: int


def load_iris_dataloaders(
    batch_size: int = 16,
    val_size: float = 0.2,
    seed: int = 42,
) -> DataBundle:
    """
    Carga el dataset Iris, separa train/validation de forma estratificada,
    estandariza las features (media 0, desvío 1) y arma DataLoaders de
    PyTorch listos para el ciclo de entrenamiento.

    Estandarizar es importante: las redes neuronales son sensibles a la
    escala de los datos de entrada.
    """
    iris = load_iris()
    X, y = iris.data, iris.target

    X_train, X_val, y_train, y_val = train_test_split(
        X,
        y,
        test_size=val_size,
        random_state=seed,
        stratify=y,
    )

    # Estandarización: se ajusta (fit) solo con train para no filtrar
    # información del conjunto de validación (data leakage).
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)

    X_train_t = torch.tensor(X_train, dtype=torch.float32)
    y_train_t = torch.tensor(y_train, dtype=torch.long)
    X_val_t = torch.tensor(X_val, dtype=torch.float32)
    y_val_t = torch.tensor(y_val, dtype=torch.long)

    train_ds = TensorDataset(X_train_t, y_train_t)
    val_ds = TensorDataset(X_val_t, y_val_t)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    return DataBundle(
        train_loader=train_loader,
        val_loader=val_loader,
        input_dim=X.shape[1],
        num_classes=int(np.unique(y).size),
    )
